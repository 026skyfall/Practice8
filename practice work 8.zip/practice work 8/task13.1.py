# task 13.1
(lambda x: print(*[min(x[i]) for i in range(0, len(x), 1)])) ([[1, -5, 3, 4], [4, 8, -3], [-12, 10, 5, 0]])